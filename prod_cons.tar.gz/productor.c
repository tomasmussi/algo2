/* 
 * File:   productor.c
 * Author: fede
 *
 * Created on September 9, 2013, 11:06 PM
 */

#include "Cola.h"
#include "producto.h"
#include "mensaje.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>

int main(int argc, char** argv)
{
	int id_productor = 1;
	int id_consumidor = 2;
	size_t largo_mensaje = sizeof(mensaje_t) - sizeof(long);
	size_t largo_producto = sizeof(producto_t) - sizeof(long);
	srand(time(NULL)  + id_productor);

	int cola = cola_obtener_id(".", 'A');
	if(cola == -1)
	{
		char mensaje[120];
		sprintf(mensaje, "PRODUCTOR: no se pudo obtener acceso a la cola.\n");
		write(fileno(stdout), mensaje, strlen(mensaje));
		exit (-1);  
	}
    
	/* Envío diez productos al consumidor. */
	for(int i = 0; i < 10; i++)
	{
		producto_t prod;
		prod.mtype = id_consumidor;
		prod.nro_serie = rand();
		char anuncio[120];
		sprintf(anuncio, "PRODUCTOR: produzco el producto con ID %d.\n", prod.nro_serie);
		write(fileno(stdout), anuncio, strlen(anuncio));

		int res = cola_enviar(cola, &prod, largo_producto);
		if(res == -1)
		{
			char mensaje[120] = "PRODUCTOR: error de escritura.";
			write(fileno(stdout), mensaje, strlen(mensaje));
			exit (-1);
		}
		
		cola_recibir(cola, &prod, largo_mensaje, id_productor);

		sleep(1);
	}
	
	/* Envío mensaje de fin. */
	producto_t prod;
	prod.mtype = id_consumidor;
	prod.nro_serie = MENSAJE_FINALIZACION;
	char anuncio[120] = "PRODUCTOR: produzco mensaje de fin.\n";
	write(fileno(stdout), anuncio, strlen(anuncio));
	cola_enviar(cola, &prod, largo_mensaje);
    
	return 0;
}

