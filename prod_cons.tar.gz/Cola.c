#include "Cola.h"
#include <sys/types.h>
#include <sys/msg.h>
#include <sys/ipc.h>

int cola_crear(const char* archivo, char letra)
{
    key_t clave = ftok(archivo, letra);
    int res = msgget(clave, IPC_CREAT | IPC_EXCL | 0660);
    return res;    
}

int cola_obtener_id(const char* archivo, char letra)
{
    key_t clave = ftok(archivo, letra);
    int res = msgget(clave, 0660);
    return res;
}

int cola_enviar(int cola_id, const void* mensaje, size_t tam_mensaje)
{
    int res = msgsnd(cola_id, mensaje, tam_mensaje, 0);
    return res;
}

size_t cola_recibir(int cola_id, void* buffer, size_t tam_buffer, int msgtyp)
{
    int res = msgrcv(cola_id, buffer, tam_buffer, msgtyp, 0);
    return res;    
}

void cola_destruir(int cola_id)
{
    msgctl(cola_id, IPC_RMID, NULL);
}
