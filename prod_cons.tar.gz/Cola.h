/* 
 * File:   Cola.h
 * Author: fede
 *
 * Created on September 8, 2013, 2:23 PM
 */

#ifndef COLA_H
#define	COLA_H

#define _XOPEN_SOURCE 500

#include <stddef.h>

/* Dado un archivo al que se debe tener acceso por todos los procesos 
involucrados en la comunicación y una letra identificatoria, crea una cola. */
int cola_crear(const char* archivo, char letra);

/* Obtiene el ID de una cola creada dados sus identificadores. */
int cola_obtener_id(const char* archivo, char letra);

/* Envía un mensaje en la cola.
Requiere el identificador de la cola, una estructura de mensaje que tenga un 
miembro llamado mtype de tipo long en dónde se seteará el destinatario, y el 
tamaño del mensaje. 
Devuelve -1 en caso de error.*/
int cola_enviar(int cola_id, const void* mensaje, size_t tam_mensaje);

/* Recibe un mensaje en la cola, este método es bloqueante.
Requiere el identificador de la cola, un buffer, su tamaño y un código de 
recepción de mensaje. */
size_t cola_recibir(int cola_id, void* buffer, size_t tam_buffer, int msgtyp);

/* Destruye una cola dado su identificador. */
void cola_destruir(int cola_id);

#endif	/* COLA_H */

