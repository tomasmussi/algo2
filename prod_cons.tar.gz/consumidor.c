/* 
 * File:   consumidor.c
 * Author: fede
 *
 * Created on September 9, 2013, 11:07 PM
 */

#include "Cola.h"
#include "producto.h"
#include "mensaje.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>

int main(int argc, char** argv) 
{
	int id_productor = 1;
	int id_consumidor = 2;
	size_t largo_mensaje = sizeof(mensaje_t) - sizeof(long);
	size_t largo_producto = sizeof(producto_t) - sizeof(long);

	int cola = cola_obtener_id(".", 'A');
	if(cola == -1)
	{
		char mensaje[120] = "CONSUMIDOR: no se pudo obtener acceso a la cola.\n";
		write(fileno(stdout), mensaje, strlen(mensaje));
		exit (-1);               
	}

	int numero_serie = 0;
	while(numero_serie != MENSAJE_FINALIZACION)
	{
		/* Leo cola del productor. */
		producto_t prod;
		cola_recibir(cola, &prod, largo_producto, id_consumidor);
		numero_serie = prod.nro_serie;
			
		char mensaje[120];
		sprintf(mensaje, "CONSUMIDOR: consumo elemento con ID %d.\n", numero_serie);
		write(fileno(stdout), mensaje, strlen(mensaje));
		
		/* Respondo OK. */
		mensaje_t mens;
		mens.mtype = id_productor;
		mens.mensaje = OK;
		cola_enviar(cola, &mens, largo_mensaje);
	}

	return 0;
}

