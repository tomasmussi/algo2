/* 
 * File:   destruir_ipc.c
 * Author: fede
 *
 * Created on September 8, 2013, 2:18 PM
 */

#define _XOPEN_SOURCE 500

#include "Cola.h"

int main(int argc, char** argv) 
{
    int colaid1 = cola_obtener_id("/home/fede/", 'A');
    cola_destruir(colaid1);
    return 0;
}



