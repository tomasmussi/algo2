/* 
 * File:   mensaje.h
 * Author: fede
 *
 * Created on September 9, 2013, 11:28 PM
 */

#ifndef MENSAJE_H
#define	MENSAJE_H

#define OK 0
#define FINALIZACION -1

typedef struct mensaje
{
    long mtype;
    int mensaje;
} mensaje_t;

#endif	/* MENSAJE_H */

