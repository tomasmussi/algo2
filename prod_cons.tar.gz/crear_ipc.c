/* 
 * File:   crear_ipc.c
 * Author: fede
 *
 * Created on September 8, 2013, 2:18 PM
 */

#define _XOPEN_SOURCE 500

#include "Cola.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char** argv)
{
    int res_cola = cola_crear(".", 'A');
    if(res_cola == -1)
    {
        char mensaje[120] = "Error en la creación de las colas.\n";
        write(fileno(stdout), mensaje, strlen(mensaje));
        exit (-1);
    }
    
    return 0;
}

