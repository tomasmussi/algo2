/* 
 * File:   producto.h
 * Author: fede
 *
 * Created on September 9, 2013, 11:28 PM
 */

#ifndef PRODUCTO_H
#define	PRODUCTO_H

#define MENSAJE_FINALIZACION -1

typedef struct producto
{
    long mtype;
    int nro_serie;
} producto_t;

#endif	/* PRODUCTO_H */

